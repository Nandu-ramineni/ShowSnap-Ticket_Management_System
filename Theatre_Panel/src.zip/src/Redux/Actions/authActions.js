import Cookies from "js-cookie";
import axios from "@/lib/axiosInstance";
import * as ActionTypes from "../Constants/authConstants";

export const login = (email, password) => async (dispatch) => {
    try {
        dispatch({ type: ActionTypes.AUTH_LOGIN_REQUEST });
        const { data } = await axios.post("/auth/login", { email, password });
        const { accessToken, refreshToken, user } = data.data;
        Cookies.set("accessToken", accessToken, { secure: true, sameSite: "Strict" });
        Cookies.set("refreshToken", refreshToken, { secure: true, sameSite: "Strict" });
        dispatch({
            type: ActionTypes.AUTH_LOGIN_SUCCESS,
            payload: user,
        });
    } catch (error) {
        dispatch({
            type: ActionTypes.AUTH_LOGIN_FAILURE,
            payload: error.response?.data?.message || "Login failed",
        });
    }
};