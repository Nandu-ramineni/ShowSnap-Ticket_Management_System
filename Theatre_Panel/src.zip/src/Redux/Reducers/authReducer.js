import * as ActionTypes from '../Constants/authConstants';

const initialState = {
    loading: false,
    user: null,
    error: null,
};

export const authReducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionTypes.AUTH_LOGIN_REQUEST:
            return { ...state, loading: true };

        case ActionTypes.AUTH_LOGIN_SUCCESS:
            return {
                loading: false,
                user: action.payload,
                error: null,
            };

        case ActionTypes.AUTH_LOGIN_FAILURE:
            return {
                loading: false,
                user: null,
                error: action.payload,
            };

        case ActionTypes.AUTH_LOGOUT:
            return initialState;

        default:
            return state;
    }
};