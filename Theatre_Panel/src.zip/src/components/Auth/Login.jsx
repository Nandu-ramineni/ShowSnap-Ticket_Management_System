
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Logo from "@/assets/Logo.png"
import { useState } from "react"

const initialData = {
    email: "",
    password: "",
};

const Login = () => {
    const [formData, setFormData] = useState(initialData);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Form submitted:", formData);
    }

    // ── Render ───────────────────────────────────────────────────────────────
    return (
        <main className="flex justify-center items-center min-h-screen px-4">
            <Card className="w-full max-w-sm">

                {/* Branding */}
                <div className="flex flex-col items-center pt-6 gap-1 select-none">
                    <img src={Logo} alt="CineVault logo" className="w-16 h-16" />
                    <h1 className="text-2xl font-bold">CineVault!</h1>
                    <p className="text-sm text-muted-foreground">Your seats. Your cinema.</p>
                </div>

                <CardHeader>
                    <CardTitle>Login to your account</CardTitle>
                    <CardDescription>Enter your credentials below.</CardDescription>
                </CardHeader>

                <CardContent>
                    <form
                        id="loginForm"
                        onSubmit={handleSubmit}
                        noValidate
                        aria-label="Login form"
                    >
                        <div className="flex flex-col gap-5">

                            {/* Email */}
                            <div className="grid gap-1.5">
                                <Label htmlFor="email">Email</Label>
                                <Input
                                    id="email"
                                    name="email"
                                    type="email"
                                    autoComplete="email"
                                    inputMode="email"
                                    placeholder="hello@cinevault.com"
                                    onChange={handleChange}
                                />

                            </div>

                            {/* Password */}
                            <div className="grid gap-1.5">
                                <div className="flex items-center justify-between">
                                    <Label htmlFor="password">Password</Label>
                                    <Link
                                        to="/forgot-password"

                                        className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2 transition-colors"
                                    >
                                        Forgot password?
                                    </Link>
                                </div>
                                <Input
                                    value={formData.password}
                                    id="password"
                                    name="password"
                                    type="password"
                                    autoComplete="current-password"
                                    onChange={handleChange}


                                />

                            </div>

                        </div>
                    </form>
                </CardContent>

                <CardFooter className="flex-col gap-3">
                    <Button
                        type="submit"
                        form="loginForm"
                        className="w-full"

                    >
                        Login
                    </Button>

                    <p className="text-sm text-muted-foreground text-center">
                        Don&apos;t have an account?{" "}
                        <Link
                            to="/signup"
                            className="font-medium text-foreground hover:underline underline-offset-2"
                        >
                            Sign up
                        </Link>
                    </p>
                </CardFooter>

            </Card>
        </main>
    )
}

export default Login