import { Navigate } from "react-router-dom";
import Cookies from "js-cookie";

const PublicRoute = ({ children }) => {
    const token = Cookies.get("accessToken");

    return token ? <Navigate to="/dashboard" replace /> : children;
};

export default PublicRoute;