import * as adminService from './admin.service.js';
import { sendSuccess, sendCreated } from '../../utils/ApiResponse.js';
import TheatreOwner from './theatreOwner.model.js';
import ApiError from '../../utils/ApiError.js';
import { body, param, query } from 'express-validator';
const asyncHandler = (fn) => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);

const getMeta = (req) => ({
    ip: req.headers['x-forwarded-for']?.split(',')[0].trim() ?? req.socket.remoteAddress,
    userAgent: req.headers['user-agent'] ?? 'unknown',
});


// ─── Approve ─────────────────────────────────────────────────────────────────

export const getPendingApprovals = async ({ page = 1, limit = 20 }) => {
    const skip = (page - 1) * limit;
    const [owners, total] = await Promise.all([
        TheatreOwner.find({ accountStatus: ACCOUNT_STATUS.PENDING })
            .sort({ createdAt: 1 })
            .skip(skip)
            .limit(limit),
        TheatreOwner.countDocuments({ accountStatus: ACCOUNT_STATUS.PENDING }),
    ]);
    return { owners, total };
};

export const approveTheatreOwner = async (ownerId) => {
    const owner = await TheatreOwner.findOneAndUpdate(
        { _id: ownerId, accountStatus: ACCOUNT_STATUS.PENDING },
        { accountStatus: ACCOUNT_STATUS.ACTIVE },
        { new: true }
    );
    if (!owner) throw ApiError.notFound('Pending owner not found');
    return owner;
};

export const rejectTheatreOwner = async () => {
    const ownerId = req.params.ownerId;
    const reason = req.body;
    if(!ownerId) {
        throw ApiError.badRequest('Owner ID is required');
    }
    if(!reason) {
        throw ApiError.badRequest('Rejection reason is required');
    }
    if (reason.length > 500) {
        throw ApiError.badRequest('Rejection reason must be 500 characters or fewer');
    }
    
    if (!owner) throw ApiError.notFound('Pending owner not found');
    const owner = await adminService.rejectOwner(ownerId, reason);
        res.json({ success: true, data: { owner }, message: 'Account rejected' });
    return owner;
};
